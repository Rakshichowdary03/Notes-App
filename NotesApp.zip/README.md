# NotesApp - Java File I/O Task

## Objective
A simple CLI-based notes manager using Java FileReader/FileWriter for the Java Developer Internship Task.

## Features
- Write and append notes.
- Overwrite notes.
- View saved notes.

## Technologies
- Java
- VS Code
- Terminal

## How to Run
1. Compile: `javac NotesApp.java`
2. Run: `java NotesApp`

## Concepts Demonstrated
- File I/O (`FileReader`, `BufferedReader`, `FileWriter`)
- Exception handling
- CLI user interaction

## Author
Internship Task Submission – Java File I/O